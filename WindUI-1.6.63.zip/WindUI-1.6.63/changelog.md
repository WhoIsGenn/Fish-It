# 1.6.63
## Changelog:
- Added `Window:SetSize(size: UDim2)` and `Window:SetPanelBackground(number)`
- Added `Boxborder: boolean` to `Section` (section inside the tab)
- Added `CanClose: boolean` to `Notification` element
- Added `Desc` to Section (section inside the tab)
- Added `Border: boolean` to `Tag` element
- Added `IconSize` to dropdown tabs
- Added some fallbacks for themes
- Added `IconRadius` to `Window`
- Added `:Destroy()` to tag
- Added `LockedTitle` to elements
- Fixed error with game.Players
- Fixed Tag text color
- Fixed Dialog
- Fixed Searchbar isnt destroyed
- Design changes (glass outline; notification, searchbar, tabs, etc)